# ADS1115-Lite

Stripped down version with bug fixes from the adafruit ADS1015/ADS1115 library in order to save as much space as possible

A more complete library can be found here: https://github.com/soligen2010/Adafruit_ADS1X15

Adapted from adafruit ADS1015/ADS1115 library
